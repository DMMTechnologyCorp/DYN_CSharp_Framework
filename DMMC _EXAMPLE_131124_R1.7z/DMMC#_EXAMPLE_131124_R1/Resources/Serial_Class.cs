﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMMDRV5_DEV_251024_R1.Resources
{
    internal class Serial_Class
    {
    }

    public static class ClassSERIAL
    {
        public static void WriteByte(byte c)
        {
            var data = new byte[] { c };
            GLOBAL_VARIABLE.port1.Write(data, 0, 1);
        }

        public static void WritePackage()
        {
            int i;
            byte c;
            while (GLOBAL_VARIABLE.OutBfBtmPointer != GLOBAL_VARIABLE.OutBfTopPointer)
            {
                c = (byte)(GLOBAL_VARIABLE.OutputBuffer[GLOBAL_VARIABLE.OutBfBtmPointer]);
                WriteByte(c);
                GLOBAL_VARIABLE.OutBfBtmPointer++;
                i = 10;
                while (i != 0)
                {
                    i--;
                }
            }
        }


        public static void Make_CRC_Send(int Plength, byte[] B)
        {
            int Error_Check = 0;
            for (int i = 0; i < Plength - 1; i++)
            {
                GLOBAL_VARIABLE.OutputBuffer[GLOBAL_VARIABLE.OutBfTopPointer] = B[i];
                GLOBAL_VARIABLE.OutBfTopPointer++;
                Error_Check += B[i];
            }
            Error_Check = Error_Check | 0x80;
            GLOBAL_VARIABLE.OutputBuffer[GLOBAL_VARIABLE.OutBfTopPointer] = Error_Check;
            GLOBAL_VARIABLE.OutBfTopPointer++;

            WritePackage();
        }



        public static void Send_Package(int Function, int ID, long Displacement)
        {
            var B = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
            int Package_Length, Function_Code, Global_Func;
            Global_Func = Function;

            int TEMP_INT; TEMP_INT = 0;

            long TempLong;
            B[1] = B[2] = B[3] = B[4] = B[5] = 0x80;
            TEMP_INT = ID & 0x7f;
            B[0] = (byte)(ID & 0x7f);
            Function_Code = Global_Func & 0x1f;

            TempLong = Displacement & 0x0fffffff;       //Max 28bits
            B[5] += (byte)(TempLong & 0x0000007f);
            TempLong = TempLong >> 7;
            B[4] += (byte)(TempLong & 0x0000007f);
            TempLong = TempLong >> 7;
            B[3] += (byte)(TempLong & 0x0000007f);
            TempLong = TempLong >> 7;
            B[2] += (byte)(TempLong & 0x0000007f);
            Package_Length = 7;

            TempLong = Displacement;
            TempLong = TempLong >> 20;
            if ((TempLong == 0x00000000) || (TempLong == 0xffffffff))
            {//Three byte data
                B[2] = B[3];
                B[3] = B[4];
                B[4] = B[5];
                Package_Length = 6;
            }

            TempLong = Displacement;
            TempLong = TempLong >> 13;
            if ((TempLong == 0x00000000) || (TempLong == 0xffffffff))
            {//Two byte data
                B[2] = B[3];
                B[3] = B[4];
                Package_Length = 5;
            }

            TempLong = Displacement;
            TempLong = TempLong >> 6;
            if ((TempLong == 0x00000000) || (TempLong == 0xffffffff))
            {//One byte data
                B[2] = B[3];
                Package_Length = 4;
            }

            B[1] += (byte)((Package_Length - 4) * 32 + Function_Code);

            Make_CRC_Send(Package_Length, B);
        }


        public static void ReadPackage(int Function)
        {
            int c, cif;
            int Read_Flag;
            //char szBuff[6]={0};
            int dwBytesRead = 0;
            //DWORD dwCommModemStatus;

            var data = new byte[10];
            //var data = new byte[10] { 11, 22, 33, 44, 55, 66, 77, 88, 99, 00 };
            //int[] array2 = { 1, 2, 3, 4, 5, 6 };
            //byte[] array1 = new byte[10];
            //data = { 11,22,33,44,55,66,77,88,99,00};

            try
            {
                Read_Flag = GLOBAL_VARIABLE.port1.Read(data, 0, 1); dwBytesRead++;
            }
            catch (TimeoutException e)
            {
                Read_Flag = 0;
            }

            while (Read_Flag != 0) //public int Read (byte[] buffer, int offset, int count);
            {
                GLOBAL_VARIABLE.InputBuffer[GLOBAL_VARIABLE.InBfTopPointer] = data[0];
                GLOBAL_VARIABLE.InBfTopPointer++;

                try
                {
                    Read_Flag = GLOBAL_VARIABLE.port1.Read(data, 0, 1); dwBytesRead++;
                }
                catch (TimeoutException e)
                {
                    Read_Flag = 0;
                }
            }

            //Read_Flag = ReadFile(hPort, &c, 1, &dwBytesRead, NULL);
            //while (dwBytesRead == 1)
            //{
            //    //cout<<"Byte Read!"<<"\n";
            //    GLOBAL_VARIABLE.InputBuffer[GLOBAL_VARIABLE.InBfTopPointer] = c;
            //    GLOBAL_VARIABLE.InBfTopPointer++;
            //    Read_Flag = ReadFile(hPort, &c, 1, &dwBytesRead, NULL);
            //}

            while (GLOBAL_VARIABLE.InBfBtmPointer != GLOBAL_VARIABLE.InBfTopPointer)
            {
                //cout<<"123"<<"\n";
                c = GLOBAL_VARIABLE.InputBuffer[GLOBAL_VARIABLE.InBfBtmPointer];
                GLOBAL_VARIABLE.InBfBtmPointer++;
                cif = c & 0x80;

                if (cif == 0)
                {
                    GLOBAL_VARIABLE.Read_Num = 0;
                    GLOBAL_VARIABLE.Read_Package_Length = 0;
                }

                if (cif == 0 || GLOBAL_VARIABLE.Read_Num > 0)
                {
                    GLOBAL_VARIABLE.Read_Package_Buffer[GLOBAL_VARIABLE.Read_Num] = c;
                    GLOBAL_VARIABLE.Read_Num++;
                    if (GLOBAL_VARIABLE.Read_Num == 2)
                    {
                        cif = c >> 5;
                        cif = cif & 0x03;
                        GLOBAL_VARIABLE.Read_Package_Length = 4 + cif;
                        c = 0;
                    }

                    if (GLOBAL_VARIABLE.Read_Num == GLOBAL_VARIABLE.Read_Package_Length)
                    {
                        Get_Function();
                        GLOBAL_VARIABLE.Read_Num = 0;
                        GLOBAL_VARIABLE.Read_Package_Length = 0;
                    }
                }
            }
        }

        public static void Get_Function()
        {
            int ID, Function_Code, CRC_Check;
            int TempPos32, Temp32;

            int[] temp_array1 = new int[8];

            temp_array1[0] = GLOBAL_VARIABLE.Read_Package_Buffer[0];
            temp_array1[1] = GLOBAL_VARIABLE.Read_Package_Buffer[1];
            temp_array1[2] = GLOBAL_VARIABLE.Read_Package_Buffer[2];
            temp_array1[3] = GLOBAL_VARIABLE.Read_Package_Buffer[3];

            ID = GLOBAL_VARIABLE.Read_Package_Buffer[0] & 0x7f;
            Function_Code = GLOBAL_VARIABLE.Read_Package_Buffer[1] & 0x1f;

            CRC_Check = 0;
            for (int i = 0; i < GLOBAL_VARIABLE.Read_Package_Length - 1; i++)
            {
                CRC_Check += GLOBAL_VARIABLE.Read_Package_Buffer[i];
            }
            CRC_Check ^= GLOBAL_VARIABLE.Read_Package_Buffer[GLOBAL_VARIABLE.Read_Package_Length - 1];
            CRC_Check &= 0x7f;
            if (CRC_Check != 0)
            {
                //MessageBox::Show(L"There is CRC Error",L"CRC Error",MessageBoxButtons::OK,MessageBoxIcon::Error);
            }
            else
            {
                switch (Function_Code)
                {
                    case 0x10:  //#define Is_MainGain             0x10
                        GLOBAL_VARIABLE.Driver_MainGain = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_MainGain = GLOBAL_VARIABLE.Driver_MainGain & 0x7f;
                        break;
                    case 0x11:  //#define Is_SpeedGain            0x11
                        GLOBAL_VARIABLE.Driver_SpeedGain = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_SpeedGain = GLOBAL_VARIABLE.Driver_SpeedGain & 0x7f;
                        break;
                    case 0x12:  //#define Is_IntGain              0x12
                        GLOBAL_VARIABLE.Driver_IntGain = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_IntGain = GLOBAL_VARIABLE.Driver_IntGain & 0x7f;
                        break;
                    case 0x13:  //#define Set_TrqCons             0x13
                        Temp32 = Cal_Value(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_TorqueCons = Temp32 & 0x0000FFFF;
                        Temp32 >>= 8;
                        GLOBAL_VARIABLE.Driver_Torque_Limit = Temp32 & 0x0000FFFF;
                        Temp32 >>= 8;
                        GLOBAL_VARIABLE.Driver_PulseFilter = Temp32 & 0x0000FFFF;
                        break;
                    case 0x14:  //#define	Is_HighSpeed			0x14
                        Temp32 = Cal_Value(GLOBAL_VARIABLE.Read_Package_Buffer);// 301024 changed to cal value from signedvalue since signed value return wrong data???
                        GLOBAL_VARIABLE.Driver_HighSpeed = (char)Temp32;
                        GLOBAL_VARIABLE.Driver_HighSpeed = GLOBAL_VARIABLE.Driver_HighSpeed & 0x7f;
                        Temp32 >>= 8;
                        GLOBAL_VARIABLE.Driver_Speed_Limit = Temp32 & 0xffff;
                        break;
                    case 0x15:  //#define Is_HighAccel			0x15
                        GLOBAL_VARIABLE.Driver_HighAccel = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_HighAccel = GLOBAL_VARIABLE.Driver_HighAccel & 0x7f;
                        break;
                    case 0x16:  //#define	Is_Driver_ID			0x16
                        GLOBAL_VARIABLE.Driver_ReadID = ID;
                        break;
                    case 0x17:  //#define Is_Pos_OnRange          0x17
                        GLOBAL_VARIABLE.Driver_OnRange = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_OnRange = GLOBAL_VARIABLE.Driver_OnRange & 0x7f;
                        break;
                    case 0x18:  //#define	Is_FoldNumber			0x18
                        Temp32 = Cal_Value(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_Fold_Number = Temp32 & 0x0000ffff;
                        if (ID < 3)
                            GLOBAL_VARIABLE.Gear_Number[ID] = GLOBAL_VARIABLE.Driver_Fold_Number;
                        Temp32 = Temp32 >> 16;
                        GLOBAL_VARIABLE.Driver_EncoderLine_Number = Temp32;
                        break;
                    case 0x19:  //#define Is_Status               0x19
                        GLOBAL_VARIABLE.Driver_Status = (byte)Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        break;
                    case 0x1a: //#define Is_Config               0x1a
                        Temp32 = Cal_Value(GLOBAL_VARIABLE.Read_Package_Buffer);
                        GLOBAL_VARIABLE.Driver_Config0 = Temp32 & 0x0000FFFF;
                        Temp32 >>= 8;
                        GLOBAL_VARIABLE.Driver_Config1 = Temp32 & 0x0000FFFF;
                        Temp32 >>= 8;
                        GLOBAL_VARIABLE.Driver_Config2 = Temp32 & 0x0000FFFF;
                        break;
                    case 0x1b:   //#define Is_AbsPos32				0x1b		// Absolute position 32
                        GLOBAL_VARIABLE.Motor_Pos32 = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        break;
                    case 0x1d:   //#define Is_MotorSpeed			0x1d		// Motor speed
                        GLOBAL_VARIABLE.Motor_Spd = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        break;
                    case 0x1e:   ////#define Is_TrqCurrent			0x1e
                        GLOBAL_VARIABLE.MotorTorqueCurrent = Cal_SignValue(GLOBAL_VARIABLE.Read_Package_Buffer);
                        break;

                    default:
                        break;
                }
            }
        }

        public static int Cal_SignValue(int[] onePackage)
        {
            int length = 4 + ((onePackage[1] >> 5) & 0x03);
            int lcmd = onePackage[2] & 0x7F;  // Command value without sign bit
            bool sign = (onePackage[2] & 0x40) != 0;  // Check sign bit

            for (int i = 3; i < length - 1; i++)  // Process remaining bytes
            {
                lcmd = (lcmd << 7) | (onePackage[i] & 0x7F);
            }

            // Apply sign extension based on the initial sign
            if (sign)
            {
                lcmd -= (1 << (7 * (length - 3)));
            }

            return lcmd;  // -2^17 to 2^17 - 1
        }

        public static int Cal_Value(int[] One_Package)
        {
            int Package_Length, OneChar, i;
            int Lcmd;
            OneChar = One_Package[1];
            OneChar = OneChar >> 5;
            OneChar = OneChar & 0x03;
            Package_Length = 4 + OneChar;

            OneChar = One_Package[2];       /*First byte 0x7f, bit 6 reprents sign			*/
            OneChar &= 0x7f;
            Lcmd = OneChar;           /*Sign extended to 32bits						*/
            for (i = 3; i < Package_Length - 1; i++)
            {
                OneChar = One_Package[i];
                OneChar &= 0x7f;
                Lcmd = Lcmd << 7;
                Lcmd += OneChar;
            }
            return (Lcmd);                  /*Lcmd : -2^27 ~ 2^27 - 1						*/
        }


        public static byte TestSerialInit(byte port_number)
        {
            switch (port_number)
            {
                case 1: GLOBAL_VARIABLE.port1 = new SerialPort("COM1", 38400, Parity.None, 8, StopBits.One); break;
                case 2: GLOBAL_VARIABLE.port1 = new SerialPort("COM2", 38400, Parity.None, 8, StopBits.One); break;
                case 3: GLOBAL_VARIABLE.port1 = new SerialPort("COM3", 38400, Parity.None, 8, StopBits.One); break;
                case 4: GLOBAL_VARIABLE.port1 = new SerialPort("COM4", 38400, Parity.None, 8, StopBits.One); break;
                case 5: GLOBAL_VARIABLE.port1 = new SerialPort("COM5", 38400, Parity.None, 8, StopBits.One); break;
                case 6: GLOBAL_VARIABLE.port1 = new SerialPort("COM6", 38400, Parity.None, 8, StopBits.One); break;
                case 7: GLOBAL_VARIABLE.port1 = new SerialPort("COM7", 38400, Parity.None, 8, StopBits.One); break;
                case 8: GLOBAL_VARIABLE.port1 = new SerialPort("COM8", 38400, Parity.None, 8, StopBits.One); break;
                default: break;
            }

            try
            {
                GLOBAL_VARIABLE.port1.Open();
            }
            catch (IOException e)
            {
                return 0x00;    // problem opening serial port, return 0x00 serial problem
            }
            catch (UnauthorizedAccessException e1)
            {
                return 0x01;    // problem opening serial port, return 0x00 serial problem ; most likely serial port already open
            }

            //if opening port is ok, set below timeouts
            GLOBAL_VARIABLE.port1.ReadTimeout = 50;
            GLOBAL_VARIABLE.port1.WriteTimeout = 50;

            //if above is normal, try reading main gain
            if (ClassSERIAL.ReadMainGain() != 0)    // read main gain got some number which is main gain, if 0, then COM port is not servo drive since no reply
            {
                GLOBAL_VARIABLE.UserComPortNumber = port_number;
                return 0xff;
            }
            else { GLOBAL_VARIABLE.port1.Close(); return 0x02;  }


            return 0x00;    // all normal return 0xff all normal
        }

        public static int DetectCOMPort(int i)
        {
            switch (i)
            {
                case 1: GLOBAL_VARIABLE.port1 = new SerialPort("COM1", 38400, Parity.None, 8, StopBits.One); break;
                case 2: GLOBAL_VARIABLE.port1 = new SerialPort("COM2", 38400, Parity.None, 8, StopBits.One); break;
                case 3: GLOBAL_VARIABLE.port1 = new SerialPort("COM3", 38400, Parity.None, 8, StopBits.One); break;
                case 4: GLOBAL_VARIABLE.port1 = new SerialPort("COM4", 38400, Parity.None, 8, StopBits.One); break;
                case 5: GLOBAL_VARIABLE.port1 = new SerialPort("COM5", 38400, Parity.None, 8, StopBits.One); break;
                case 6: GLOBAL_VARIABLE.port1 = new SerialPort("COM6", 38400, Parity.None, 8, StopBits.One); break;
                case 7: GLOBAL_VARIABLE.port1 = new SerialPort("COM7", 38400, Parity.None, 8, StopBits.One); break;
                case 8: GLOBAL_VARIABLE.port1 = new SerialPort("COM8", 38400, Parity.None, 8, StopBits.One); break;
                default: break;
            }
            try
            {
                GLOBAL_VARIABLE.port1.Open();
            }
            catch (IOException e)
            {
                return 0xff;    // problem opening serial port, return 0x00 serial problem
            }
            catch (UnauthorizedAccessException e1)
            {
                return 0xff;    // problem opening serial port, return 0x00 serial problem ; most likely serial port already open
            }
            GLOBAL_VARIABLE.port1.Close();
            return i;
        }
        
        public static void Process_Drive_IP(int[] Read_Package_Buffer)
        {
            int Temp32;
            byte Temp8;

            Temp32 = Cal_SignValue(Read_Package_Buffer);
            Temp32 >>= 16; Temp8 = (byte)Temp32;
            Temp32 = Cal_SignValue(Read_Package_Buffer);
            if (Temp8 == 0x22)
            {
                Temp32 = Cal_SignValue(Read_Package_Buffer);
                GLOBAL_VARIABLE.Drive_IP2 = Temp32; Temp32 >>= 8;
                GLOBAL_VARIABLE.Drive_IP3 = Temp32;
            }
            else if (Temp8 == 0x23)
            {
                Temp32 = Cal_SignValue(Read_Package_Buffer);
                GLOBAL_VARIABLE.Drive_IP0 = Temp32; Temp32 >>= 8;
                GLOBAL_VARIABLE.Drive_IP1 = Temp32;
            }
        }

        public static int ReadMainGain()
        {
            ClassSERIAL.Send_Package(0x18, 127, 0x00);  //#define Read_MainGain           0x18
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x10);  //#define Is_MainGain             0x10
            return GLOBAL_VARIABLE.Driver_MainGain;
        }
        public static int ReadSpeedGain()
        {
            ClassSERIAL.Send_Package(0x19, 127, 0x00);  //#define Read_SpeedGain          0x19
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x11);  //#define Is_SpeedGain            0x11
            return GLOBAL_VARIABLE.Driver_SpeedGain;
        }
        public static long ReadPos32()
        {
            ClassSERIAL.Send_Package(0x0e, 127, 0x1b); //0x1b		// Absolute position 32
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x1b);
            return GLOBAL_VARIABLE.Motor_Pos32;
        }
        public static long ReadSpeed32()
        {
            ClassSERIAL.Send_Package(0x0e, 127, 0x1d); //#define Is_MotorSpeed			0x1d		// Motor speed
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x1d);
            return (int)GLOBAL_VARIABLE.Motor_Spd;
        }
        public static long ReadTorque()
        {
            ClassSERIAL.Send_Package(0x0e, 127, 0x1e); //#define Is_TrqCurrent			0x1e
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x1d);
            return (int)GLOBAL_VARIABLE.MotorTorqueCurrent;
        }
        public static long ReadStatus()
        {
            ClassSERIAL.Send_Package(0x09, 127, 0x00); //#define Read_Driver_Status      0x09
            System.Threading.Thread.Sleep(5);
            ClassSERIAL.ReadPackage(0x19);  // #define Is_Status               0x19
            return (int)GLOBAL_VARIABLE.Driver_Status;
        }
        public static void Drive_Reset_RS232()
        {ClassSERIAL.Send_Package(0x0e, 127, 0x1c);  //#define Is_DRIVE_RESET           0x1c
        }
        //ClassSERIAL.Send_Package(0x0a, 127, -Convert.ToInt16(textBox1_TESTSPEED.Text)); // test speed command
        public static void SpeedCommand(int command)
        {ClassSERIAL.Send_Package(0x0a, 127, command); // #define Turn_ConstSpeed	        0x0a
        }
        public static void RelativePositionCommand(int command)
        {ClassSERIAL.Send_Package(0x03, 127, command); // #define Go_Relative_Pos			0x03
        }
        public static void AbsolutePositionCommand(int command)
        {ClassSERIAL.Send_Package(0x01, 127, command);//#define Go_Absolute_Pos			0x01
        }
        public static void Drive_Disable_RS232()
        {
            ClassSERIAL.Send_Package(0x0e, 127, 0x21);//#define General_Read			0x0e    #define Is_DriveDisable			0x21
        }
        public static void Drive_Enable_RS232()
        {
            ClassSERIAL.Send_Package(0x0e, 127, 0x20);//#define General_Read			0x0e    #define Is_DriveEnable			0x20
        }
        public static void SetSpeedGain(int command)
        {
            ClassSERIAL.Send_Package(0x11, 127, command); // #define Set_SpeedGain           0x11
        }
    }



}
