﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMMDRV5_DEV_251024_R1
{
    internal class Global_Variables
    {

    }

    public static class GLOBAL_VARIABLE
    {
        public static int Global_Func;

        public static bool IS_MODULE_OPEN;

        public static int[] InputBuffer = new int[256];//int[] B = new int[5];
        public static int[] OutputBuffer = new int[256];
        public static int Read_Num, Read_Package_Length;
        public static int[] Read_Package_Buffer = new int[8];
        public static byte InBfTopPointer, InBfBtmPointer;
        public static byte OutBfTopPointer, OutBfBtmPointer;

        public static SerialPort port1;
        public static bool Serial_Port_IsOpen;
        public static int UserComPortNumber;

        public static int Is_MainGain = 0x10;

        public static int Driver_MainGain, Driver_SpeedGain, Driver_IntGain,
            Driver_TorqueCons, Driver_HighSpeed, Driver_HighAccel,
            Driver_FolderNumber, Driver_ID,
            Driver_Torque_Limit, Driver_PulseFilter, Driver_Speed_Limit,
            Driver_ReadID, Driver_OnRange, Driver_Fold_Number, Driver_EncoderLine_Number;
        public static byte Driver_Status;
        public static int Driver_Config0;
        public static int Driver_Config1;       // Added Sept 7, 2017 for modbus/CAN donfig
        public static int Driver_Config2;       // Added July 15, 2021 for DYN5
        public static int Driver_MotorDef;

        public static int[] Gear_Number = new int[3];//int[] B = new int[5];
        public static int[] Motor_Status = new int[128];

        public static long Motor_Pos32, Motor_Spd;
        public static int MotorTorqueCurrent, OnPos_read, Pos_Error_Reading;
        public static int Motor_Alarm_Level;
        public static int Drive_IP3, Drive_IP2, Drive_IP1, Drive_IP0;


        //Follows are used for Machine Code interpreting
        public static int Line_Error =  0xff;  //#define Line_Error			0xff
        public static int Line_OK =     0x00;//#define Line_OK				0x00
        public static int Motor_OnPos = 0x00;//#define Motor_OnPos			0x00
        public static int Motor_Busy =  0x01;//#define Motor_Busy			0x01
        public static int Motor_Free =  0x02;//#define Motor_Free			0x02
        public static int Motor_Alarm = 0x03;//#define Motor_Alarm			0x03

        public static int SAVE_Driver_MainGain, SAVE_Driver_SpeedGain, SAVE_Driver_IntGain,
        SAVE_Driver_TorqueCons, SAVE_Driver_HighSpeed, SAVE_Driver_HighAccel,
        SAVE_Driver_FolderNumber, SAVE_Driver_ID,
        SAVE_Driver_Torque_Limit, SAVE_Driver_PulseFilter, SAVE_Driver_Speed_Limit,
        SAVE_Driver_ReadID, SAVE_Driver_OnRange, SAVE_Driver_Fold_Number, SAVE_Driver_EncoderLine_Number;
        public static char SAVE_Driver_Config0;
        public static char SAVE_Driver_Config1;       // Added Sept 7, 2017 for modbus/CAN donfig
        public static char SAVE_Driver_Config2;       // Added July 15, 2021 for DYN5
        public static int SAVE_Driver_MotorDef;


    }




}
