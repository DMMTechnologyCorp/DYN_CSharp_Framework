﻿using DMMDRV5_DEV_251024_R1.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMMDRV5_DEV_251024_R1
{
    public partial class ComSetDialog : Form
    {
        byte SerialErrorFlag;

        public ComSetDialog()
        {
            InitializeComponent();
        }

        private void AUTO_SET_BUTTON_Click(object sender, EventArgs e)
        {

        }

        private void SET_COM_BTN_Click(object sender, EventArgs e)
        {
            SerialErrorFlag = 0xff; //reset serial error flag to be no error 0xff, 0x00 means error
            Application.DoEvents();
            System.Threading.Thread.Sleep(100);
            SerialErrorFlag = ClassSERIAL.TestSerialInit(Convert.ToByte(comboBox1.Text));

            if (SerialErrorFlag == 0x00)
            {
                MessageBox.Show("Error:  There is problem setting serial COM Port.\n\nPlease check COM port number.",
                                "DMMDRV5", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
            }
            else if (SerialErrorFlag == 0x01)
            {
                MessageBox.Show("Notice: COM Port is already Set.",
                                "DMMDRV5", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
            }
            else if (SerialErrorFlag == 0x02)
            {
                MessageBox.Show("Error:  Error communicating with servo drive.\n\nMake sure servo drive is powered ON and COM port is correct",
                "DMMDRV5", MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation);
            }
            else if (SerialErrorFlag == 0xff)
            {
                MessageBox.Show("COM Port Setting Successful.",
                                "DMMDRV5", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                groupBox2.Enabled = true;

                timer1.Enabled = true;
            }
        }

        private void ComSetDialog_Load(object sender, EventArgs e)
        {
            comboBox1.Text = "1";
            groupBox2.Enabled = false;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            COM_PORT_HELP_DIALOG f2 = new COM_PORT_HELP_DIALOG();
            f2.ShowDialog();
        }

        private void DETECT_COM_BTN_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            for (int i = 1; i < 9; i++)
            {
                System.Threading.Thread.Sleep(250);
                if (ClassSERIAL.DetectCOMPort(i) != 0xff)//0xff=exception when trying to open, if no exception, then possible
                {
                    MessageBox.Show("Possible COM Port: COM"+Convert.ToString(i),
                                    "DMMDRV5", MessageBoxButtons.OK,
                                    MessageBoxIcon.Exclamation);
                }
            }
            MessageBox.Show("COM Port Detection Complete\n\nIf No COM Port was detected, Make sure USB cable driver is installed and cable is connected to servo drive.",
                "DMMDRV5", MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(ClassSERIAL.ReadPos32());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = Convert.ToString(ClassSERIAL.ReadSpeed32());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Text = Convert.ToString(ClassSERIAL.ReadMainGain());
        }

        private void button4_Click(object sender, EventArgs e)
        {   // Speed Command
            int CHECK_VALUE = Convert.ToInt32(textBox4.Text);
            if (!(-1000 <= CHECK_VALUE && CHECK_VALUE <= 1000))
            { MessageBox.Show("Command Outside Range", "DMMDRV5", MessageBoxButtons.OK); }
            else { ClassSERIAL.SpeedCommand(CHECK_VALUE); }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox7.Text = Convert.ToString(ClassSERIAL.ReadStatus());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClassSERIAL.RelativePositionCommand(Convert.ToInt32(textBox5.Text));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClassSERIAL.AbsolutePositionCommand(Convert.ToInt32(textBox6.Text));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ClassSERIAL.Drive_Reset_RS232();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ClassSERIAL.Drive_Disable_RS232();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ClassSERIAL.Drive_Enable_RS232();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox8.Text = Convert.ToString(ClassSERIAL.ReadTorque());
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox9.Text = Convert.ToString(ClassSERIAL.ReadSpeedGain());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            ClassSERIAL.SetSpeedGain(Convert.ToInt32(textBox10.Text));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox11.Text = Convert.ToString(ClassSERIAL.ReadPos32());
        }
    }
}
